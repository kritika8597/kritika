package com.example.kp.androidapp;

/**
 * Created by KP on 7/10/2018.
 */

class TextView2 {
    public static void setText(String content) {
    }
}
